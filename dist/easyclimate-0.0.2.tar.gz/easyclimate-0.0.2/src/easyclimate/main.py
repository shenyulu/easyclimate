import os
my = os.getcwd()